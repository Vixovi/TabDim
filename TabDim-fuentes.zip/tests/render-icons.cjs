const {chromium}=require('C:/Users/Aivancito/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
const fs=require('node:fs');
(async()=>{
  const browser=await chromium.launch({headless:true,executablePath:process.env.TEST_CHROME});
  const page=await browser.newPage({viewport:{width:640,height:280}});
  const source=fs.readFileSync('brillo-por-pestana/icon.js','utf8').replaceAll('export ','');
  await page.evaluate(source+';globalThis.drawIcon=drawIcon;');
  for(const size of [16,32,48,128]){
    const data=await page.evaluate(size=>{const c=document.createElement('canvas');c.width=c.height=size;c.getContext('2d').putImageData(drawIcon(100,size),0,0);return c.toDataURL();},size);
    fs.writeFileSync(`brillo-por-pestana/icons/${size}.png`,Buffer.from(data.split(',')[1],'base64'));
  }
  await page.setContent('<style>body{margin:0;background:#101a2d;color:#f0f5ff;font:18px system-ui;display:flex;justify-content:space-evenly;text-align:center;padding:32px}canvas{display:block;margin-bottom:16px}</style>');
  await page.evaluate(()=>{for(const v of [100,55,10]){const div=document.createElement('div'),c=document.createElement('canvas');c.width=c.height=128;c.getContext('2d').putImageData(drawIcon(v,128),0,0);div.append(c,document.createTextNode(`${v} %`));document.body.append(div);}});
  await page.screenshot({path:'publicacion/propuestas/icono-indicador-v2.png'});
  await browser.close();
})().catch(e=>{console.error(e);process.exitCode=1;});
