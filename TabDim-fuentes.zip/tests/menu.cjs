const vm=require('node:vm'),fs=require('node:fs'),assert=require('node:assert/strict');
(async()=>{
  for(const supported of [true,false]){
    const events={},values={},created=[],windows=[];
    const event=name=>({addListener(fn){events[name]=fn;}});
    const chrome={runtime:{id:'test',getURL:p=>'chrome-extension://test/'+p,onInstalled:event('install'),onStartup:event('startup'),onMessage:event('message')},
      storage:{session:{async get(k){return {[k]:values[k]};},async set(v){Object.assign(values,v);},async remove(k){delete values[k];}}},
      contextMenus:{async removeAll(){},create(p,cb){if(p.contexts[0]==='tab'&&!supported)throw new Error('Unsupported tab');created.push(p);cb();},onClicked:event('click')},
      tabs:{onRemoved:event('removed'),onUpdated:event('updated'),onActivated:event('activated')},windows:{async create(p){windows.push(p);}}};
    const source=fs.readFileSync('brillo-por-pestana/state.js','utf8').replaceAll('export ','')+fs.readFileSync('brillo-por-pestana/worker.js','utf8').replace(/^import[^\n]+\n/gm,'');
    vm.runInNewContext(source,{chrome,console,URL});events.install();await new Promise(r=>setTimeout(r,10));
    assert.equal(values.menuContext,supported?'tab':'page');
    events.click({menuItemId:'brightness'},{id:417,active:false});await new Promise(r=>setTimeout(r,10));
    assert.equal(windows[0].url,'chrome-extension://test/control.html?tabId=417');
    console.log('PASS: simulación de API '+(supported?'tab admitido':'fallback page')+' y tabId inactivo 417.');
  }
})().catch(e=>{console.error(e);process.exitCode=1;});
