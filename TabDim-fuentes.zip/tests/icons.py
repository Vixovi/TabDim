import pathlib, struct, zlib, math
root = pathlib.Path(__file__).resolve().parents[1] / 'brillo-por-pestana' / 'icons'
root.mkdir(exist_ok=True)
def chunk(t, b):
    return struct.pack('>I', len(b)) + t + b + struct.pack('>I', zlib.crc32(t+b))
for n in (16,32,48,128):
    rows=[]
    for y in range(n):
        row=bytearray([0])
        for x in range(n):
            dx,dy=(x+.5)/n-.5,(y+.5)/n-.5
            r=math.hypot(dx,dy)
            angle=math.atan2(dy,dx)
            sun=r<.19 or (.25<r<.35 and abs(math.sin(angle*4))<.24)
            row.extend((255,218,95,255) if sun else (23,77,186,255))
        rows.append(row)
    data=b'\x89PNG\r\n\x1a\n'+chunk(b'IHDR',struct.pack('>IIBBBBB',n,n,8,6,0,0,0))+chunk(b'IDAT',zlib.compress(b''.join(rows)))+chunk(b'IEND',b'')
    (root/f'{n}.png').write_bytes(data)
