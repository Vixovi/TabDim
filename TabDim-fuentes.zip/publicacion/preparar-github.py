from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
import shutil
root = Path(__file__).resolve().parents[1]
dest = root / 'publicacion' / 'github-upload'
dest.mkdir(exist_ok=True)
for name in ['manifest.json','worker.js','state.js','shade.js','icon.js','control.html','control.js','control.css','VERIFICACION.md']:
    shutil.copy2(root/'brillo-por-pestana'/name, dest/name)
shutil.copy2(root/'brillo-por-pestana'/'README.md', dest/'MANUAL.md')
shutil.copy2(root/'publicacion'/'README-GITHUB.md', dest/'README.md')
for name in ['FICHA.md','PRIVACIDAD.md','TabDim-WebStore-1.1.1.zip']:
    shutil.copy2(root/'publicacion'/name,dest/name)
for file in (root/'publicacion'/'imagenes-tienda').glob('*.png'):
    shutil.copy2(file,dest/file.name)
shutil.copy2(root/'TabDim.zip',dest/'TabDim.zip')
with ZipFile(dest/'TabDim-fuentes.zip','w',ZIP_DEFLATED) as z:
    for folder in ['brillo-por-pestana','tests','publicacion']:
        for f in (root/folder).rglob('*'):
            if not f.is_file(): continue
            rel=f.relative_to(root)
            if any(part.startswith('profile-') or part=='github-upload' for part in rel.parts): continue
            if f.name in {'privacidad-publicada.png', 'github-publicado.png', 'github-revisado.png'}: continue
            z.write(f,rel.as_posix())
    z.write(root/'TabDim.zip','TabDim.zip')
print(dest)
