from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
import json

root = Path(__file__).resolve().parents[1]
source = root / 'brillo-por-pestana'
files = ['manifest.json', 'worker.js', 'state.js', 'shade.js', 'icon.js', 'control.html', 'control.js', 'control.css']
files += [f'icons/{size}.png' for size in (16, 32, 48, 128)]
version = json.loads((source / 'manifest.json').read_text(encoding='utf-8'))['version']
target = root / 'publicacion' / f'TabDim-WebStore-{version}.zip'
with ZipFile(target, 'w', ZIP_DEFLATED) as archive:
    for name in files:
        archive.write(source / name, name)
with ZipFile(target) as archive:
    assert archive.testzip() is None
    assert 'manifest.json' in archive.namelist()
print(target)
