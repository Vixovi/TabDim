# TabDim 1.1.1 — estado de publicación

Vixovi ha confirmado que la extensión ya está enviada a Chrome Web Store y pendiente de aprobación por Google.

El repositorio público https://github.com/Vixovi/TabDim permite revisar el código, la documentación, los permisos, la privacidad y los recursos gráficos. El paquete TabDim-WebStore-1.1.1.zip es una copia de referencia de la versión enviada.

La política de privacidad está publicada en https://github.com/Vixovi/TabDim/blob/main/PRIVACIDAD.md.

Cuando Google apruebe la extensión y exista una ficha pública, se añadirá el enlace oficial al README. Los límites de las comprobaciones están documentados en brillo-por-pestana/VERIFICACION.md.
