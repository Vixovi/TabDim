# Subir TabDim 1.1.1 a Chrome Web Store

Estado: paquete preparado; no subido ni enviado a revisión. El acceso automatizado al panel fue rechazado con «The extensions gallery cannot be scripted».

1. En el panel de Chrome Web Store, crea un nuevo elemento y carga `TabDim-WebStore-1.1.1.zip` de esta carpeta. El manifest está en la raíz del ZIP; no uses el ZIP con carpeta pensado para instalación descomprimida.
2. Completa nombre y descripción con `FICHA.md`. Idioma: español. Desarrollador y contacto: Vixovi, Vixovi@proton.me.
3. Usa las capturas reales `propuestas/control-claro.png` y `propuestas/control-oscuro.png` (640 × 400). Corresponden a la interfaz ejecutada en Chromium con una pestaña de prueba local, no a un montaje de interfaz.
4. El icono es `../brillo-por-pestana/icons/128.png`. El paquete ya contiene el mismo icono.
5. La portada aprobada es `propuestas/promocion-TabDim-v1.png`. Antes de cargarla como imagen promocional pequeña, exporta una copia a **440 × 280** manteniendo el encuadre y sin deformar el contenido. El archivo original es una propuesta de alta resolución y no tiene todavía ese tamaño de entrega. No uses `icono-dinamico-TabDim-v1.png`, que es una propuesta descartada.
6. Publica `PRIVACIDAD.md` en un repositorio público de GitHub o en una página pública propia y copia la URL accesible sin iniciar sesión en el campo de privacidad. El correo de contacto ya está completado. No se ha publicado aún; el conector de GitHub no devuelve repositorios accesibles.
7. En Privacidad usa el propósito único y las justificaciones de permisos de `FICHA.md`. Declara que no hay código remoto; la extensión no transmite datos a servidores. Revisa las definiciones exactas de las casillas del panel antes de confirmarlas.
8. Completa distribución y datos que solicite el panel. Mantén las advertencias de páginas protegidas y límites de pantalla completa en la descripción.
9. Revisa `../brillo-por-pestana/VERIFICACION.md`: el menú nativo en Chrome instalado y vídeo fullscreen no se han comprobado automáticamente. Haz las pruebas manuales correspondientes antes del envío.
10. Guarda el borrador. Cuando estén completos los campos e imágenes y la URL de privacidad sea pública, envía a revisión. Solo Google puede aprobar la extensión.

Referencias oficiales consultadas:
- https://developer.chrome.com/docs/webstore/publish
- https://developer.chrome.com/docs/webstore/images
